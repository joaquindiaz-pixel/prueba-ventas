gsap.registerPlugin(ScrollTrigger);
console.log("main loaded");